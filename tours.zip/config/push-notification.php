<?php

return array(

    'appNameIOS'     => array(
        'environment' =>'development',
        'certificate' =>'/path/to/certificate.pem',
        'passPhrase'  =>'password',
        'service'     =>'apns'
    ),
    'Android' => array(
        'environment' =>'production',
        'apiKey'      =>'AIzaSyD-eiaNceXRvUOMSrwqtirvWFfn4kz6mXo',
        'service'     =>'gcm'
    )

);