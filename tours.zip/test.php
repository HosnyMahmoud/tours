<?
phpinfo();
?>
