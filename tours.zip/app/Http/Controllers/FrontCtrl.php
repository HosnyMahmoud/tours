<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Travels ;
use App\Hotel ;
use App\Countries;
use App\Cities;
use Session;
class FrontCtrl extends Controller {
	
	/***** home page ****************/
	public function index()
	{
		$travels = Travels::latest('created_at')->take(4)->get();
		//dd($travels);
		return View('front.index',compact('travels'));
	}

	// all travels 
	public function travels(Request $request)
	{
		$query = Travels::latest('created_at');
		if($request->has('type'))
		{
			$query->where('type',$request->type);
		}
		$travels = $query->paginate(20);

		return View('front.travels.index',compact('travels'));
	}

	// one travel
	public function travel($id,$slug)
	{
		$travel = Travels::findOrFail($id);
		if($travel['slug_'.Session::get('local')] !== $slug )
		{
			return redirect()->to(Url('/').'/travels/'.$id.'-'.$travel['slug_'.Session::get('local')]);
		}
		return View('front.travels.travel',compact('travel'));
	}

	public function hotels(Request $request)
	{
		$regions = [];
		$countries = Countries::all();
		$cities = Cities::get();
		
		$i = 0;
		foreach ($countries as $country) {
			$cities = Cities::where('country_id',$country->id)->get();
			$z = 0;
			foreach ($cities as $city) {
			 
				$regions[$country['name_'.Session::get('local')]][$city['id']]  =  $city['name_'.Session::get('local')]; 
				$z++;	
			}

			$i++;
		}
		
		$query = Hotel::latest('created_at');
		if($request->has('type'))
		{
			$query->where('type',$request->type);
		}
		$hotels = $query->paginate(20);

		return View('front.hotels.index',compact('hotels','regions','countries','cities'));
	}

	// one travel
	public function hotel($id,$slug)
	{
		$hotels = Hotel::findOrFail($id);
		if($hotels['slug_'.Session::get('local')] !== $slug )
		{
			return redirect()->to(Url('/').'/travels/'.$id.'-'.$hotels['slug_'.Session::get('local')]);
		}
		return View('front.hotels.hotel',compact('hotels'));
	}

}
